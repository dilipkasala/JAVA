package flowerpack;

public class Jasmine extends Flower
{
	public Jasmine()
	{
		this.cost = 10;
	}
}
