package flowerpack;

public class Lilly extends Flower
{
	public Lilly()
	{
		this.cost = 23;
	}
}
