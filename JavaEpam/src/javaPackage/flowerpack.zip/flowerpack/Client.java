package flowerpack;
import flowerpack.Bouquet;

public class Client 
{

	public static void main(String[] args)
	{
		
		Bouquet FlowerBouquest = new Bouquet();
		FlowerBouquest.
		FlowerBouquest.add("Rose");
		FlowerBouquest.add(new Jasmine());
		FlowerBouquest.add(new Lilly());
		FlowerBouquest.add(10, new Rose());
	}
		
}
