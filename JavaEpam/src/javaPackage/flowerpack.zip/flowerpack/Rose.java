package flowerpack;

public class Rose extends Flower {
	
	public Rose()
	{
		this.cost = 4;
	}

}
