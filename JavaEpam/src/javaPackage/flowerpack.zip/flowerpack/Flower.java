package flowerpack;

public abstract class Flower 
{

	protected int cost ;
	public int getCost()
	{
		return cost;
	}  
}
