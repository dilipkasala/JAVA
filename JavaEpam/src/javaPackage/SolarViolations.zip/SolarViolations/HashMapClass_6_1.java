package com.epam.test;

import java.io.File;
import java.util.HashMap;
import java.util.Map.Entry;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class HashMapClass_6_1 {
	static Logger logger = Logger.getLogger(HashSets6_1.class);
	public static void main(String[] args) 
	{
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
        

		HashMap<Integer,String> map = new HashMap<>();
		map.put(1, "Raj");
		map.put(2, "Ram");
		map.put(5, "Rohan");
		map.put(6, "Rinku");
		map.put(4, "Raghu");
		map.put(3, "Rahim");
		
		String text =map.get(5);
		// To get required index and value
		logger.info(text);
		
		map.put(4, "xyz"); // overrides the value
		String t = map.get(4);
		logger.info("This is override value :" + t);
		
		
		map.remove(3); // remove an item from the record
		for(Entry<Integer, String> m:map.entrySet())
		{
			logger.info(m.getKey() + " - " + m.getValue());
		}
		
		int i = map.size();
		logger.info("Size of hash map - " + i);
		

		
		
		
		
		
		

	}

}
