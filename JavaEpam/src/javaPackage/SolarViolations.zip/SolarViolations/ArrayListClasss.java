package EpamPackage;
import java.io.File;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator; 

public class ArrayListClasss
{
	static Logger logger = Logger.getLogger(ArrayListClasss.class);

	public static void main(String[] args)
	{

		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
        
		ArrayList<String> a1 = new ArrayList<String>();
		
		a1.add("one");
		a1.add("two");
		a1.add("three");
		a1.add("four");
		a1.add("five");
		a1.add("six");
		a1.add("seven");
		a1.add("eight");
		a1.add("nine");
		a1.add("ten");
			
		logger.info("This is type 1 retrieving list");
		for(String str : a1){
			logger.info(str);
		}
		
		logger.info("\nThis is type 2 retrieving list");
		logger.info(a1.get(2));
		
		logger.info("Remove the 1 item from last records");
		a1.remove(a1.size() - 3);
		
		logger.info("\nThis is type 3 retrieving list");
		for (int i = 0; i < a1.size(); i++) 
		{
			logger.info(a1.get(i));
        }	

	}

}
