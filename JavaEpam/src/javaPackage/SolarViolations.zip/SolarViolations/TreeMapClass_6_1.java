package com.epam.test;

import java.io.File;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TreeMapClass_6_1 
{
	static Logger logger = Logger.getLogger(TreeMapClass_6_1.class);
	
	public static void main(String[] args){
	
	{
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
		
		
		TreeMap<String,String> tmap = new TreeMap<>(); 
	    tmap.put("1", "First");
	    tmap.put("2", "Second");
	    tmap.put("3", "Third");
	    tmap.put("4", "Fourth");
	    
	    if(!tmap.isEmpty())
	    {
	    	logger.info(tmap.size());
	    	logger.info(tmap.get("3"));
	    }
	    
	    //Copying list from one treemap to other
	    TreeMap<String, String> subMap = new TreeMap<String, String>();
        subMap.put("5", "Sixth");
        subMap.put("6", "Seventh");
        tmap.putAll(subMap);
        logger.info(tmap);
             
        // reverse the list
        Map<String, String> reversetmap = tmap.descendingMap();
        logger.info("Reverse Map List: " + reversetmap );
        
        // To get key set
        Set<String> tmapkeys = tmap.keySet();
        for(String key: tmapkeys)
        {
        	logger.info("These are key sets :-" + key);
        }
	}
	}
}

