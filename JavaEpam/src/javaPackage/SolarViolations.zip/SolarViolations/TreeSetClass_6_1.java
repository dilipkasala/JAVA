package com.epam.test;

import java.io.File;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TreeSetClass_6_1 {

	private static TreeSet<String> unique;
	static Logger logger = Logger.getLogger(TreeMapClass_6_1.class);
	

	public static void main(String[] args) 
	{
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
		
		TreeSet<String> ts = new TreeSet<>();
		ts.add("A");
		ts.add("B");
		ts.add("D");
		ts.add("C");
		ts.add("C");
		
		logger.info(ts);
		Iterator<String> itr= ts.iterator();
		while(itr.hasNext())
		{
			logger.info(itr.next());
		}
		
		// to remove an element if list is non empty
		if(!ts.isEmpty()) {
			try 
			{
				logger.info("Element D is removed from the list" + ts.remove("D"));
				logger.info("The size of the list is: " + ts.size());
			}
			catch(Exception e)
			{
				logger.info(e.getMessage());
			}
		}
		
		// to find duplicate in array
		for(String tsarray:ts)
		{
			try
			{
				if(!unique.add(tsarray))
				{
					logger.info("Duplicate arrays:-" + tsarray);
				}
			}
			catch(Exception e)
			{
				logger.info("No duplicate found");
			}
			
		}
		
		// to get subset from tree set
		Set<String> subset= ts.subSet("G", "H");	
	    logger.info("sub set: "+subset);
	        
	}
}
