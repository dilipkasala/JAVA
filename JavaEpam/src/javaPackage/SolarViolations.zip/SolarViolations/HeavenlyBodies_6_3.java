package com.epam.test;
	
	import java.util.HashSet;
	import java.util.Set;


	public class HeavenlyBodies_6_3 {

		    private final String name;
		    private final double orbitalPeriod;
		    private final Set<HeavenlyBodies_6_3> satellites;
		    
		    
		    public HeavenlyBodies_6_3(String name, double orbitalPeriod) 
		    {
		        this.name = name;
		        this.orbitalPeriod = orbitalPeriod;
		        this.satellites = new HashSet<>();
		    }

		    public String getName() 
		    {
		        return name;
		    }

		    public double getOrbitalPeriod() 
		    {
		        return orbitalPeriod;
		    }

		    public boolean addMoon(HeavenlyBodies_6_3 moon)
		    {
		        return this.satellites.add(moon);
		    }

		    public Set<HeavenlyBodies_6_3> getSatellites() 
		    {
		        return new HashSet<>(this.satellites);
		    }

		    @Override
	        public int hashCode()
	        {
	           int hashcode = 0;
	           hashcode += orbitalPeriod;
	           return hashcode;
	        }
	         
	        @Override
	        public boolean equals(Object obj)
	        {
	            if (obj instanceof HeavenlyBodies_6_3) {
	            	HeavenlyBodies_6_3 pp = (HeavenlyBodies_6_3) obj;
	                return (pp.name.equals(this.name) && pp.orbitalPeriod == this.orbitalPeriod);
	            } else {
	                return false;
	            }
	        }
	        
}

