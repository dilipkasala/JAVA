package com.epam.test;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonTask_7_2 {
	LoginPojo loginPojo = new LoginPojo();
	ObjectMapper mapper = new ObjectMapper();

	try {
	    mapper.setVisibility(JsonMethod.FIELD, Visibility.ANY);

	    // Setting values to POJO
	    loginPojo.setEmail("a@a.com");
	    loginPojo.setLogin_request("abc");
	    loginPojo.setPassword("abc");

	    // Convert user object to json string
	    String jsonString = mapper.writeValueAsString(loginPojo);

	    // Display to console
	    System.out.println(jsonString);

	} catch (JsonGenerationException e){
	    e.printStackTrace();
	} catch (JsonMappingException e){
	    e.printStackTrace();
	} catch (IOException e){
	    e.printStackTrace();
	}

	Output : 
	{"login_request":"abc","email":"a@a.com","password":"abc"}
}
