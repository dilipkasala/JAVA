package EpamPackage;
//4.1 Task

import java.io.File;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class SpeedDriving 
{
	static Logger logger = Logger.getLogger(SpeedDriving.class);
	public static void main (String[] args){
		
		//String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
		
		logger.info(party(2,3));
		logger.info(party(3,5));
		logger.info(party(2,4));
		logger.info(party(1,3));
	}
	public int caughtSpeeding(int speed, boolean isBirthday) {
	  if (!(isBirthday)) {
	    if (speed <= 60){
	      return 0;
	    }
	    if (speed > 60 && speed <= 80){
	      return 1;
	    }
	    else{
	      return 2;
	    }
	  } else if (speed <=65){
	      return 0;
	  }
	    else if (speed > 65 && speed <= 85){
	      return 1;
	    }else{
	      return 2;
	    }
	}
	
	public static boolean checkNum(int resNum, int num1,int num2){
		
		if (num1+num2==resNum || (num1==resNum||num2==resNum)||(num1-num2==resNum||num2-num1==resNum)){
			return true;
		}else{
			return false;
		}
	}
	
	public static int party(int tea, int candy){
		
		
		if (tea<5 || candy<5) return 0;
		else if (tea>=(candy*2)||candy>=(tea*2)) return 2;
		else return 1;
		
	}
	
	public int lottery(int a, int b, int c) {
		  if (a+b==10||a+c==10||b+c==10 ){
					return 10;
				}else if (a+b==b+c+10 ||a+b==a+c+10){
					return 	5;
				}else{
					return 0;
				}
	}
	
	
	public boolean inOrder(int a, int b, int c,boolean bok) {
		
		if (bok){
			if (c>b)return true;
			else return false;
		}else{
			if (b>a && c>b) return true;
			else return false;
		}
	}
	
	public boolean shareDigit(int a, int b) {
	 
		if ((a>=10 && a<=99) && (b>=10 && b<=99)){
		  int aLeft = a / 10;
		  int aRight = a % 10;
		  int bLeft = b / 10;
		  int bRight = b % 10;
		  if (aLeft == bLeft || aLeft == bRight || aRight == bLeft || aRight == bRight)
		    return true;
		  else
		    return false;
		}else{
			return false;
		}
	}


	public int sumCondition(int a , int b){
		
		String stringofa=String.valueOf(a);
		String stringofab=String.valueOf(a+b);
		
		if (stringofa.length()==stringofab.length()) return a+b;
		 else	return a;
	}
	
	public String removeSearchString(String base, String removeTxt){
	
		  int blen = base.length();
		  int rlen = removeTxt.length();
		  String lowbase = base.toLowerCase();
		  String lowrem = removeTxt.toLowerCase();
		  String fin = "";
		 
		  for (int icntr = 0; icntr < blen; icntr++) {
		    if (icntr <= blen - rlen) {
		      String tmp = lowbase.substring(icntr,icntr+rlen);
		      if (!tmp.equals(lowrem))
		        fin += base.substring(icntr,icntr+1);
		      else {
		        icntr += rlen-1;
		      }
		    }
		    else {
		      String tmp2 = lowbase.substring(icntr,icntr+1);
		      if (!tmp2.equals(lowrem))
		        fin += base.substring(icntr,icntr+1);
		    }
		  }
		  return fin;
	}
	

	public int maxBlock(String str) {
	      if(str.length() == 0)
	        return 0;
	          
	    int largest = 0;
	    int current = 1;
	                
	    for(int i = 1; i < str.length(); i++) {
	        if(str.charAt(i) != str.charAt(i-1)) {
	            if(current > largest)
	                largest = current;
	            current = 1;
	        } else {
	            current++;
	        }
	    }
	    return Math.max(largest, current);
	}
	
	public int sumNumbers(String str) {
	  int len = str.length();
	  int sum = 0;
	  String tmp = "";
	  for (int i = 0; i < len; i++) {
	    if (Character.isDigit(str.charAt(i))) {
	      if (i < len-1 && Character.isDigit(str.charAt(i+1))) {
	        tmp += str.charAt(i);
	      }
	      else {
	        tmp += str.charAt(i);
	        sum += Integer.parseInt(tmp);
	        tmp = "";
	      }
	    }
	  }
	  return sum;
	}
}
