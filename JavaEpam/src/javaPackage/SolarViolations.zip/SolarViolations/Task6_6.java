package com.epam.test;

import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
//Task6.6
import org.apache.log4j.PropertyConfigurator;

public class Task6_6<T>
{
	static Logger logger = Logger.getLogger(Task6_6.class);
	public void printArray(T arr[])
 {
     for(T s : arr )
     {
         logger.info(s); 
     }
}

	public static void main(String[] args) 	{
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
		
		BasicConfigurator.configure();
		
	     Task6_6 arr = new Task6_6 ();
	     // create arrays of Integer, Double and Character
	     Integer[] integerArray = {1, 2, 3, 4, 5, 6};
	     Double[] doubleArray = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7};
	     Character[] characterArray = {'H', 'E', 'L', 'L', 'O'};
	     logger.info("Array integerArray contains:");
	     arr.printArray(integerArray); // pass an Integer array
	     logger.info("\nArray doubleArray contains:");
	     arr.printArray(doubleArray); // pass a Double array
	     logger.info("\nArray characterArray contain:");
	     arr.printArray(characterArray); // pass a Character array
	}

}