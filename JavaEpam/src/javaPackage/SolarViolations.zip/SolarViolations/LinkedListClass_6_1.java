package com.epam.test;

import java.io.File;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LinkedListClass_6_1 
{
	static Logger logger = Logger.getLogger(LinkedListClass_6_1.class);
	
	public static void main(String[] args)
	{
		
		 String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
	     PropertyConfigurator.configure(log4jConfigFile);
	      
		 List<Integer> l1=new LinkedList<>();
		 l1.add(1);
		 l1.add(2);
		 l1.add(3);
		 l1.add(4);
		 l1.add(5);
		 l1.add(6);
		 l1.add(7);
		 l1.add(8);
		 l1.add(9);
		 l1.add(10);
		 
		 logger.info("\n this is type 1 retreiving the list");
		 for(Integer In : l1){
			 logger.info(In);
		 }
		 
		 //inserting new item to the list
		 l1.add(4,-4);
		 
		 logger.info("\n this is type 2 retreiving the list");
		 for (int i = 0; i < l1.size(); i++) 
			{
	            logger.info(l1.get(i));
	        }
		 
		Object o = l1.remove(9); // removed number 9 from the list
		logger.info("\n remove number" + o + " from the list");
		
		Object r = l1.lastIndexOf(8);
		logger.info("Last Index" +  r);
					
		logger.info("\n this is iterating the list");
		Iterator<Integer> iter=l1.iterator();
		{
	       while(iter.hasNext())
	       {
	    	   logger.info(iter.next());
	       }
		 }
		try
		{
		Object getNumber = l1.get(7);
		logger.info(getNumber);
		}
		catch(ArrayStoreException e)
		{
			logger.info(e.getMessage());
		}
							

	}

}
