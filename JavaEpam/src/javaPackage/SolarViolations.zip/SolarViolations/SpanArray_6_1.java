package com.epam.test;

import java.io.File;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class SpanArray_6_1 {
	static int max = 0;
	static int[] arr1 = {1, 2, 1, 1, 3};
	static int[] arr2 = {1, 4, 2, 1, 4, 1, 4};
	static int[] arr3 = {1, 4, 2, 1, 4, 4, 4};
	static Logger logger = Logger.getLogger(SpanArray_6_1.class);

	
	public static void main(String[] args) 
	{
		String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
		logger.info(span(arr1));
		logger.info(span(arr2));
		logger.info(span(arr3));
	}
	
	 public static int span(int[] nums)
	 {
	    
	    for(int i = 0; i < nums.length; i++) 
	    {
	        int j = nums.length - 1;
	              
	        if(nums[i] != nums[j])
	            j--;
	                              
	        int span = j - i + 1;
	                                      
	        if(span > max)
	            max = span;
	    }
	    return max;
	        
	 }
	  
	

}
