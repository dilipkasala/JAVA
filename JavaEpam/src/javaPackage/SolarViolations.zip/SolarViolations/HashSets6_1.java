package com.epam.test;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class HashSets6_1 {
	
	static Logger logger = Logger.getLogger(HashSets6_1.class);
	public static void main(String[] args) 
	{
		// TreeSet sorts in natural order
        Set<String> set1 = new TreeSet<String>();
        
        String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
        
        if (set1.isEmpty()) {
            logger.info("Set is empty at start");
        }

        set1.add("dog");
        set1.add("cat");
        set1.add("mouse");
        set1.add("snake");
        set1.add("bear");

        if (set1.isEmpty()) {
            logger.info("Set is empty after adding (no!)");
        }

        // Adding duplicate items does nothing.
        set1.add("mouse");

        logger.info(set1);

        // ///////// Iteration ////////////////

        for (String element : set1) {
            logger.info("this is iterative :-" + element);
        }

        // ////////// Does set contains a given item? //////////
        if (set1.contains("aardvark")) {
            logger.info("Contains aardvark");
        }

        if (set1.contains("cat")) {
            logger.info("Contains cat");
        }

        /// set2 contains some common elements with set1, and some new

        Set<String> set2 = new TreeSet<String>();

        set2.add("dog");
        set2.add("cat");
        set2.add("giraffe");
        set2.add("monkey");
        set2.add("ant");
        
        ////////////// Intersection ///////////////////
        
        Set<String> intersection = new HashSet<String>(set1);
        
        intersection.retainAll(set2);
        
        logger.info(intersection);
        
        ////////////// Difference /////////////////////////
        
        Set<String> difference = new HashSet<String>(set2);
        
        difference.removeAll(set1);
        logger.info(difference);
	}
}
