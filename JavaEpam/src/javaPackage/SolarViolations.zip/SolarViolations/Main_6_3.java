package com.epam.test;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Main_6_3 {

		private static Map<String, HeavenlyBodies_6_3> solarSystem = new HashMap<>();
	    private static Set<HeavenlyBodies_6_3> planets = new HashSet<>();
	    static Logger logger = Logger.getLogger(Main_6_3.class);

		public static void main(String[] args) 
		{
			String log4jConfigFile = System.getProperty("user.dir")+"/src/Resources/"+ File.separator + "log4j.properties";
		    PropertyConfigurator.configure(log4jConfigFile);
		       
			HeavenlyBodies_6_3 temp = new HeavenlyBodies_6_3("Mercury", 88);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        temp = new HeavenlyBodies_6_3("Venus", 225);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        temp = new HeavenlyBodies_6_3("Earth", 365);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        HeavenlyBodies_6_3 tempMoon = new HeavenlyBodies_6_3("Moon", 27);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon);

	        temp = new HeavenlyBodies_6_3("Mars", 687);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        tempMoon = new HeavenlyBodies_6_3("Deimos", 1.3);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Mars

	        tempMoon = new HeavenlyBodies_6_3("Phobos", 0.3);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Mars

	        temp = new HeavenlyBodies_6_3("Jupiter", 4332);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        tempMoon = new HeavenlyBodies_6_3("Io", 1.8);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Jupiter

	        tempMoon = new HeavenlyBodies_6_3("Europa", 3.5);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Jupiter

	        tempMoon = new HeavenlyBodies_6_3("Ganymede", 7.1);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Jupiter

	        tempMoon = new HeavenlyBodies_6_3("Callisto", 16.7);
	        solarSystem.put(tempMoon.getName(), tempMoon);
	        temp.addMoon(tempMoon); // temp is still Jupiter

	        temp = new HeavenlyBodies_6_3("Saturn", 10759);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        temp = new HeavenlyBodies_6_3("Uranus", 30660);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        temp = new HeavenlyBodies_6_3("Neptune", 165);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        temp = new HeavenlyBodies_6_3("Pluto", 248);
	        solarSystem.put(temp.getName(), temp);
	        planets.add(temp);

	        logger.info("Planets");
	        for(HeavenlyBodies_6_3 planet : planets) {
	            logger.info("\t" + planet.getName());
	        }
	        
	        HeavenlyBodies_6_3 body = solarSystem.get("Mars");
	        logger.info("Moons of " + body.getName());
	        for(HeavenlyBodies_6_3 jupiterMoon: body.getSatellites()) {
	            logger.info("\t" + jupiterMoon.getName());
	        }

	        Set<HeavenlyBodies_6_3> moons = new HashSet<>();
	        for(HeavenlyBodies_6_3 planet : planets) {
	            moons.addAll(planet.getSatellites());
	        }

	        logger.info("All Moons");
	        for(HeavenlyBodies_6_3 moon : moons) {
	            logger.info("\t" + moon.getName());
	        }


		}
}
